Since the .db file is over 150MB it has not been uploaded.
Please download it from the provided link in the paper, to run the experiments using the 10000 user dataset
